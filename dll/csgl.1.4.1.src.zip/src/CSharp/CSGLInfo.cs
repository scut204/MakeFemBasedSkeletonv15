using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("CsGL")]
[assembly: AssemblyDescription("OpenGL for .NET")]
[assembly: AssemblyCopyright("Lloyd Dupont <lloyd@galador.net>, 2001")]
[assembly: AssemblyVersion("1.4.1.0")]

#if STRONG
[assembly: AssemblyKeyFile("csgl.snk")]
#endif
